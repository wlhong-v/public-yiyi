const express = require('express');
const app = express();
const qs = require('qs')
const url = require('url')
//解析表单的插件
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({
	extended: false
}))

//创建数据库连接对象
const mysql = require('mysql');
const conn = mysql.createConnection({
	host: 'localhost', //数据库地址
	user: 'root', //账号
	password: '123456', //密码
	database: 'yiyi', //库名
	multipleStatements: true //允许执行多条语句
});

//设置跨域访问
app.all('*', function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "X-Requested-With");
	res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
	res.header("Content-Type", "application/json;charset=utf-8");
	next();
});
/* 
 用户登录注册表yi_login
 */
// 登录
app.get('/getLogin', (req, res) => {
	const account = req.query.account;
	const password = req.query.password;
	const sqlStr = 'select * from yi_login where userphone=? '
	conn.query(sqlStr, account, (err, results) => {
		if (err) return res.json({
			err_code: 1,
			message: err,
			affextedRows: 0,
		})
		if (results[0]) {
			// console.log(password)
			console.log(password)
			console.log(results[0].userpassword)
			if (results[0].userpassword === password) {
				return res.json({
					err_code: 200,
					message: '登录成功',
					taken:0
				})
			}else{
				return res.json({
					err_code: 200,
					message: '密码错误',
					taken:1
				})
			}
		}
		return res.json({
			err_code: 200,
			message: '用户不存在',
			taken:2
		})
		//  if(!result.length){
		//             return res.json({ status: 1, msg: '登录失败' })
		//         }else{
		//             // [ RowDataPacket { password: '123', username: 'admin', id: 1 } ]
		//             if(result[0].password==pwd){
		//                 return res.json({ status: 1, msg: '登录成功' })
		//             }
		//             return res.json({ status: 1, msg: '密码错误' })
		// }
	})
});
//用户注册，(查询用户id，判断是否能注册）
app.get('/getReg', (req, res) => {
	const phone = req.query.account;
	const password = req.query.password;
	console.log(phone);
	console.log(password);
	const sqlStr = 'select * from  yi_login where userphone= ?'
	const insert = 'insert into yi_login (userphone,userpassword) values(?,?)'
	const addUser = 'insert into yi_user (phone) values (?)'
	conn.query(sqlStr, phone, (err, results) => {
		if (err) {
			return res.json({
				status: 0,
				message: '请求出错1',
				affextedRows: 0
			})
		}
		if (results) {
			if (results.length !== 0) {
				return res.json({
					status: 1,
					message: '该用户已存在',
					// affextedRows: results.affextedRows
				})
			} else {
				conn.query(insert, [phone, password], (e, r) => {
					if (e) {
						console.log("注册失败")
						return res.json({
							err_code: 1,
							message: '注册失败',
							affextedRows: 0
						})
					} else {
						console.log("注册成功")
						
						return res.json({
							err_code: 200,
							message: results,
							affextedRows: results.affextedRows
						})
					}
				})
				conn.query(addUser,phone,(er,re) => {
					if (er) {
						console.log(err)
						// return res.json({
						// 	err_code: 1,
						// 	message: err,
						// 	affectedRows: 0
						// })
					}
					res.json({
						err_code: 0,
						message: '更改成功',
						affectedRows: results.affectedRows
					})
				})
			}

		}
	})
	
});

/* 
用户信息管理表yi_user 
 */
// 修改用户信息
app.get('/postsetuser', (req, res) => {
	console.log(req.query)
	var name = req.query.name;
	var phone = req.query.phone;
	var sex = req.query.sex;
	var des = req.query.describe;
	// const sqlStr =
	// 	'insert into yi_user (username,headeimg,sex,describe) where phone=?';
	const addStr = 'update yi_user set username=?, sex=?, des=? where phone=? ';
	conn.query(addStr, [name, sex, des,phone], (err, results) => {
		if (err) {
			console.log(err)
			return res.json({
				err_code: 1,
				message: err,
				affectedRows: 0
			})
		}
		res.json({
			err_code: 0,
			message: '更改成功',
			affectedRows: results.affectedRows
		})
	})
});
// 查看用户用户信息
app.get('/getusers', (req, res) => {
	const phone = req.query.phone;
	const sqlStr = 'select * from yi_user where phone=? '
	conn.query(sqlStr,phone, (err, results) => {
		console.log(results)
		if (err) return res.json({
			err_code: 1,
			message: '数据不存在',
			affextedRows: 0
		})
		res.json({
			err_code: 200,
			message: results,
			affextedRows: results.affextedRows
		})
	})
});

/* 
保单、理赔使用yi_insure数据表
 */
// 增加投保保单
app.get('/postinsure', (req, res) => {
	console.log(req.query.userphone)
	var userphone = req.query.userphone;
	var name = req.query.name;
	var type = req.query.type;
	var time = req.query.time;
	var idcard = req.query.idcard;
	var phone = req.query.phone;
	const sqlStr =
		'insert into yi_insure (phone,insure_username,insure_type,insure_time,insure_idcard,insure_phone) values(?,?,?,?,?,?)'
	conn.query(sqlStr, [userphone,name, type, time, idcard, phone], (err, results) => {
		if (err) {
			console.log(err)
			return res.json({
				err_code: 1,
				message: err,
				affectedRows: 0
			})
		}
		res.json({
			err_code: 0,
			message: '添加成功',
			affectedRows: results.affectedRows
		})
	})
});
// 查询投保保单
app.get('/getinsure', (req, res) => {
	const phone = req.query.phone
	const sqlStr = 'select * from yi_insure where phone = ?'
	conn.query(sqlStr, phone ,(err, results) => {
		console.log(results)
		if (err) return res.json({
			err_code: 1,
			message: '数据不存在',
			affextedRows: 0
		})
		res.json({
			err_code: 200,
			message: results,
			affextedRows: results.affextedRows
		})
	})
});
// 申请理赔服务API
app.get('/getclaim', (req, res) => {
	// console.log(req.query.phone)
	const phone = req.query.phone;
	const sqlStr = 'select * from yi_insure where phone = ? and insure_taken = ?'
	// insure_taken = 0 ,限制条件
	conn.query(sqlStr, [phone,0], (err, results) => {
		if (err) return res.json({
			err_code: 1,
			message: '数据不存在',
			affextedRows: 0
		})
		res.json({
			err_code: 200,
			message: results,
			affextedRows: results.affextedRows
		})
	})
});
// 根据选择的id返回申请人
app.get('/getclaimuser', (req, res) => {
	const id = req.query.id;
	const sqlStr = 'select insure_username from yi_insure where insure_id = ? '
	conn.query(sqlStr, id, (err, results) => {
		// console.log(results)
		if (err) return res.json({
			err_code: 1,
			message: '数据不存在',
			affextedRows: 0
		})
		res.json({
			err_code: 200,
			message: results,
			affextedRows: results.affextedRows
		})
	})
});
// 修改保单理赔状态
app.get('/setinsure', (req, res) => {
	// 根据保单ID修改保单理赔状态
	const iid = req.query.id;
	const taken = req.query.taken;
	const addStr = 'update yi_insure set insure_taken=? where insure_id=?';
	conn.query(addStr, [taken, iid], (err, results) => {
		if (err) {
			console.log(err)
			return res.json({
				err_code: 1,
				message: err,
				affectedRows: 0
			})
		}
		res.json({
			err_code: 0,
			message: '更改成功',
			affectedRows: results.affectedRows
		})
	})
});
// 请求理赔列表
app.get('/getclaimlist', (req, res) => {
	const phone = req.query.phone;
	// var taken = '1';
	const sqlStr = 'select * from yi_insure where phone=? and insure_taken=? '
	conn.query(sqlStr, [phone, 1 ], (err, results) => {
		if (err) return res.json({
			err_code: 1,
			message: '数据不存在',
			affextedRows: 0
		})
		res.json({
			err_code: 200,
			message: results,
			affextedRows: results.affextedRows
		})
	})
});
// 删除理赔
app.get('/delcaim', (req, res) => {
	// 根据保单ID修改保单理赔状态
	const iid = req.query.id;
	const taken = '0';
	const addStr = 'update yi_insure set insure_taken=? where insure_id=?';
	conn.query(addStr, [taken, iid], (err, results) => {
		if (err) {
			console.log(err)
			return res.json({
				err_code: 1,
				message: err,
				affectedRows: 0
			})
		}
		res.json({
			err_code: 0,
			message: '更改成功',
			affectedRows: results.affectedRows
		})
	})
});

/* 
信息查询表yi_coll 
 */
//查询收藏表单
app.get('/getcoll', (req, res) => {
	const Uphone = req.query.phone;
	console.log(Uphone)
	const sqlStr = 'select * from yi_coll where phone = ?'
	conn.query(sqlStr, Uphone,(err, results) => {
		if (err) return res.json({
			err_code: 1,
			message: '数据不存在',
			affextedRows: 0
		})
		res.json({
			err_code: 200,
			message: results,
			affextedRows: results.affextedRows
		})
	})

});
// 删除收藏信息
app.get('/delcoll', (req, res) => {
	var phone = req.query.phone;
	var title = req.query.title
	const sqlStr = 'delete from yi_coll where phone = ? and coll_title = ?'
	conn.query(sqlStr,[phone,title], (err, results) => {
		if (err) return res.json({
			err_code: 1,
			message: '数据不存在',
			affextedRows: 0
		})
		res.json({
			err_code: 200,
			message: results,
			affextedRows: results.affextedRows
		})
	})
});
// 增加收藏信息
app.get('/addcoll', (req, res) => {
	var title = req.query.title;
	var phone = req.query.phone;
	var zan = req.query.zan;
	var zan = req.query.zan;
	var iscoll = req.query.iscoll;
	var cont = req.query.cont;
	// 添加语法
	const sqlStr = `insert into yi_coll (phone,coll_title,coll_zan,coll_iscoll,coll_cont) values (?,?,?,?,?)`;
	conn.query(sqlStr, [phone,title, zan, iscoll, cont], (err, results) => {
		if (err) {
			console.log(err)
			return res.json({
				err_code: 1,
				message: '数据不存在',
				affextedRows: 0
			})
		}
		res.json({
			err_code: 200,
			message: results,
			affextedRows: results.affextedRows
		})
	})
});



// //公开静态资源静态目录
app.use(express.static("/api/"));

// 	console.log('正在监听端口3000,http://127.0.0.1:3000');
// })


var server = app.listen(3000, '127.0.0.1', function() {
	var host = server.address().address;
	var port = server.address().port;
	console.log("服务器成攻启动  地址为 http://%s:%s", host, port);
})
