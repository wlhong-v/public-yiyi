<template>
	<view class="join">
		<view class="insurenow">
			<view class="insuretitle">
				<text class="line"></text>
				<text class="tit">填写投保信息</text>
				<text class="next">以下信息关系到您的保障利益，请正确填写</text>
			</view>
			<view class="insureviews">
				<text>受保人信息</text>
				<view class="inputbox">
					<text class="input">姓&nbsp;名:</text>
					<input class="put" type="text" @blur="checkname" :value="name" placeholder="填写姓名" />
				</view>
				<view class="inputbox">
					<text class="input">身份证:</text>
					<input class="put" type="number" @blur="checkcard" :value="idcard" placeholder="填写身份证" />
				</view>
				<view class="inputbox">
					<text class="input">电&nbsp;话:</text>
					<input class="put" type="number" @blur="checkphone" :value="phone" placeholder="填写手机号" />
				</view>
			</view>
			<view class="autoplay">
				<text class="line"></text>
				<switch class="tabauto" :checked="isauto" @change="autopay" />
				<text class="tit">开通自动续费</text>
				<text class="next">自动续保开启后，中途可随时取消</text>
				<text class="next">续保保费按续保时对应的保费自动扣款</text>
				<text class="next">开通前请仔细阅读</text>
				<text class="agreement" @click="showModal('Modal')">《自动续保协议》</text>
			</view>
		</view>
		<view class="fixed"><button type="primary" class="collection" @click="inbuy">立即参保</button></view>

		<view class="cu-modal" :class="modalName == 'Modal' ? 'show' : ''">
			<view class="cu-dialog">
				<view class="cu-bar bg-white justify-end">
					<view class="content renewaltitle">自动续保协议</view>
					<view class="action" @tap="hideModal"><text class="cuIcon-close text-red"></text></view>
				</view>
				<view class="padding-xl">
					<scroll-view scroll-y="true" style="height: 500rpx;">
						<view>
							<!-- <text> -->
							根据二00X年XX月XX日签订的《XX省营运客车承运人责任保险合作协议》的相关条款和两年来全省保险情况，经甲、乙双方友好协商，就200X—200X年度续保事宜达成如下协议，以兹共同遵守：
							一、保费标准： ...... 二、协议的签订与执行
							根据200X年甲、乙双方签订的《XX省营运客车承运人责任保险合作协议》第五条之规定，在与客运企业和客运经营业户办理承运人责任保险手续时，保险人必须在所出具保单特别约定栏中写明：甲、乙双方执行的保险条款为《XX省营运客车承运人责任险保险协议》及《200X—200X年度XX省营运客车承运人责任保险合作协议续保协议》规定的全部条款，保险人负责向被保险人解释清楚其中的相关内容；若保险人在所出具的保单特别约定栏中所注明的内容与本协议内容相抵触，则一律无效。
							三、理赔服务： 1、绝对免赔：每车每次事故人民币300元。 2、财产理赔：每次事故每一旅客财产损失的赔偿限额为每人责任限额的5%。
							3、理赔时限：理赔案件发生后，保险人应严格履行《XX省营运客车承运人责任保险协议》第八条第六款之规定，及时向被保险人提供理赔服务，在索赔单证齐全且理赔金额经双方确认后，保险人每推迟一天，应按该案全部赔偿额度的万分之三处罚赔款，并支付给被保险人。
							4、保险条款及特别约定见：附件一、二。 四、关于承保协调问题： 甲、乙双方建立定期和日常
							<!-- </text> -->
						</view>
					</scroll-view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			name: '',
			idcard: '',
			phone: '',
			time: '',
			isauto: false,
			modalName: null
		};
	},
	props: {
		itype: {
			type: String,
		}
	},
	onShow: function() {
		console.log(this.itype + '类型是');
	},
	methods: {
		// 名字A
		checkname: function(e) {
			// 姓名验证规则    用于验证中英混淆
			var item = e.detail.value;
			if (item === '') {
				console.log('未输入姓名');
			} else {
				var reg = /^([\u4e00-\u9fa5]+|([a-zA-Z]+\s?)+)$/g; // /^[\一-\龥]*$/g , reg2 = /^[A-Za-z]+$/;
				if (!reg.test(item)) {
					uni.showModal({
						content: '请输入正确的姓名：',
						showCancel: false
					});
				} else {
					this.name = item;
				}
			}
			// this.name = e.detail.value
		}, // 电话
		checkphone: function(e) {
			var item = e.detail.value;
			if (item === '') {
				console.log('未输入电话');
			} else {
				if (!/^1[3456789]\d{9}$/.test(item)) {
					uni.showModal({
						content: '请输入正确的手机号：',
						showCancel: false
					});
					return false;
				} else {
					this.phone = item;
				}
			}
			// this.phone = e.detail.value
		}, 
		// 验证身份
		checkcard: function(e) {
			var item = e.detail.value;
			if (item === '') {
				console.log('未输入身份证');
			} else {
				var regIdCard = /^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;
				if (!item || !regIdCard.test(item)) {
					uni.showModal({
						content: '请输入正确的身份证',
						showCancel: false
					});
				} else {
					this.idcard = item;
				}
				// this.idcard = e.detail.value
			}
		},
		// 获取时间
		getTime: function() {
			var date = new Date(),
				year = date.getFullYear(),
				month = date.getMonth() + 1,
				day = date.getDate();
			month >= 1 && month <= 9 ? (month = '0' + month) : '';
			day >= 0 && day <= 9 ? (day = '0' + day) : '';
			var timer = year + '-' + month + '-' + day;
			this.time = timer;
			uni.setStorageSync('time', timer);
		},
		// 参保
		inbuy(e) {
			console.log("进行请求");
			// 获取时间
			this.getTime();
			var userphone = uni.getStorageSync('username')
				// 拦截
			if (this.name && this.phone && this.idcard !== null) {
				this.$axios
					.get(
						'http://127.0.0.1:3000/postinsure',
						{
							params: {
								userphone:userphone,
								name: this.name,
								type: this.itype,
								time: this.time,
								idcard: this.idcard,
								phone: this.phone
							}
						},
						{
							headers: {
								'Content-Type': 'application/x-www-form-urlencoded'
							}
						}
					)
					.then(res => {
						console.log(res.config.name);
						console.log('请求成功');
						uni.showModal({
							content:'参保成功',
							showCancel:false
						})
					})
					.catch(err => {
						console.log(err + '请求失败');
					});
			}else{
				uni.showModal({
					content: '请填写完整信息',
					showCancel: false
				})
			}
		},
		autopay() {
			console.log((this.isauto = !this.isauto));
		},
		//
		showModal(e) {
			this.modalName = e;
		},
		hideModal(e) {
			this.modalName = null;
		}
	}
};
</script>

<style>
/* 投保信息 */
.insurenow {
	width: 100%;
	background-color: #ffffff;
}
.insuretitle {
	width: 100%;
	height: 120rpx;
}
/* .insureviews input{
		display: inline-block;
		width: 400rpx;
	} */

.line {
	display: inline-block;
	width: 10rpx;
	height: 40rpx;
	background-color: #ee9900;
	border-radius: 5rpx;
}
.next {
	display: block;
	font-size: 26rpx;
	color: #cccccc;
}

.tit {
	font-size: 50rpx;
	margin-left: 20rpx;
}
.input {
	display: inline-block;
	width: 150rpx;
}
.put {
	position: absolute;
	top: 25rpx;
	left: 150rpx;
}
.inputbox {
	position: relative;
	width: 100%;
	height: 100rpx;
	line-height: 100rpx;
	display: flex;
	border-bottom: 1rpx solid #c0c0c0;
}
/* 自动续费 */
.autoplay {
	position: relative;
	margin-top: 20rpx;
	margin-bottom: 240rpx;
}
.tabauto {
	position: absolute;
	right: 50rpx;
	top: 20rpx;
}
.agreement {
	display: inline-block;
	font-size: 26rpx;
	color: #ee9900;
	position: absolute;
	top: 146rpx;
	left: 200rpx;
}

/* 底部固定 */
.fixed {
	z-index: 99;
	width: 100%;
	height: 120rpx;
	position: fixed;
	bottom: 0rpx;
	border-radius: 20rpx;
	display: flex;
}
.collection {
	text-align: center;
	border-radius: 100rpx;
	width: 80%;
	height: 120rpx;
	line-height: 120rpx;
	color: #ffffff;
	font-size: 50rpx;
}
.collection_active {
	color: #fb3131;
}
.renewaltitle {
	line-height: 50rpx !important;
}
.padding-xl {
	padding: 5rpx 20rpx;
}
</style>
