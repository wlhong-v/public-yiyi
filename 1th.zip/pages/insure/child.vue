<template>
	<view class="child">
		<view class="bannerImg"><image src="../../static/img/childImg.jpg" mode="aspectFill" style="width: 100%; height: 350rpx;"></image></view>
		<view class="tab">
			<text class="flam dom1" @click="moveto(1)">商品详情</text>
			<text class="flam dom2" @click="moveto(2)">保障计划</text>
			<text class="flam2 dom3" @click="moveto(3)">我要投保</text>
		</view>
		<view class="childCont"><image class="imgContent" src="../../static/img/childContent.jpg" mode="widthFix"></image></view>

		<view class="footer">
			<view class="price">
				<view class="title"><text>经典版</text></view>
				<view class="list">
					<text>人身意外伤害-身故、残疾</text>
					<text class="money">200,000元</text>
				</view>
				<view class="list">
					<text>短期找寻费用补偿津贴</text>
					<text class="money">50,000元</text>
				</view>
				<view class="list">
					<text>长期找寻费用补偿津贴</text>
					<text class="money">200,000元</text>
				</view>
				<view class="listLine"></view>
				<view class="list">
					<text>保障期限</text>
					<text class="money">1年</text>
				</view>
				<view class="list">
					<text>适用人群</text>
					<text class="money">儿童</text>
				</view>
				<view class="sumMoney">
					<text>499</text>
					元起
				</view>
			</view>
		</view>
		<join :itype="insuretype"></join>
	</view>
</template>

<script>
import join from '../../components/common/join.vue';
export default {
	data() {
		return {
			insuretype: '防儿童走失险'
		};
	},
	components: { join },
	
	onLoad: function(option) {},
	onReady: function() {
		// let dom1 = uni.createSelectorQuery().select('.dom1');
		// dom1.boundingClientRect(function(data) {
		// 	console.log(data); // 获取元素信息
		// }).exec();
		// let dom2 = uni.createSelectorQuery().select('.dom2');
		// dom2.boundingClientRect(function(data) {
		// 	console.log(data); // 获取元素信息
		// }).exec();
		// let dom3 = uni.createSelectorQuery().select('.dom3');
		// dom3.boundingClientRect(function(data) {
		// 	console.log(data); // 获取元素信息
		// }).exec();
		this.moveto();
	},
	methods: {
		moveto(e) {
			switch (e) {
				case 1:
						uni.createSelectorQuery()
							.select('.child')
							.boundingClientRect(data => {
								uni.createSelectorQuery()
									.select('.dom1')
									.boundingClientRect(res => {
										// 跳转节点
										uni.pageScrollTo({
											//跳转花时
											duration: 300,
											scrollTop: res.top - data.top
										});
									})
									.exec();
							})
							.exec();
					break;
				case 2:
					uni.createSelectorQuery()
						.select('.child')
						.boundingClientRect(data => {
							uni.createSelectorQuery()
								.select('.demo2')
								.boundingClientRect(res => {
									uni.pageScrollTo({
										duration: 300,
										scrollTop: 700
									});
								})
								.exec();
						})
						.exec();

					break;
				case 3:
					uni.createSelectorQuery()
						.select('.child')
						.boundingClientRect(data => {
							uni.createSelectorQuery()
								.select('.footer')
								.boundingClientRect(res => {
									uni.pageScrollTo({
										duration: 300,
										scrollTop: res.top - data.top
									});
								})
								.exec();
						})
						.exec();
					break;
				default:
					break;
			}
		}
	}
};
</script>

<style>
.child {
	width: 100%;
	height: 100%;
	margin: 0rpx 20rpx;
}
.bannerImg {
	width: 100%;
	height: 350rpx;
	overflow: hidden;
}
.tab {
	width: 100%;
	height: 100rpx;
	margin-top: 30rpx;
	margin-bottom: 30rpx;
	background-color: #ffffff;
	color: #666666;
	border-bottom: 1rpx solid #cccccc;
	display: flex;
	justify-content: space-around;
}
.flam,
.flam2 {
	position: relative;
	display: inline-block;
	width: 33%;
	height: 100rpx;
	line-height: 100rpx;
	text-align: center;
}
.flam::after {
	content: ' ';
	display: inline-block;
	position: absolute;
	left: 100%;
	top: 30rpx;
	width: 6rpx;
	height: 40rpx;
	background-color: #cccccc;
}

/* 内容 */
.imgContent {
	width: 100%;
	height: 100%;
}
/* 价格 */
.footer {
	width: 100%;
	height: 100%;
	margin-bottom: 40rpx;
	background-color: #ffffff;
}
.price {
	/* width: 100%; */
	height: 100%;
	margin: 0 20rpx;
	border: 1rpx solid #cccccc;
	border-radius: 10rpx;
}
.title {
	width: 100%;
	height: 80rpx;
	background-color: #12c287;
	color: #feffff;
	text-align: center;
	line-height: 80rpx;
	margin-bottom: 20rpx;
}
.list {
	position: relative;
	margin-left: 30rpx;
	width: 100%;
	height: 100rpx;
	line-height: 100rpx;
	color: #828282;
}
.listLine {
	display: inline-block;
	width: 100%;
	height: 1rpx;
	border-top: 1rpx dotted #cccccc;
}
.money {
	position: absolute;
	right: 40rpx;
}
.sumMoney {
	padding-right: 20rpx;
	border-top: 1rpx solid #cccccc;
	height: 120rpx;
	text-align: right;
	line-height: 120rpx;
	color: #828282;
}

.sumMoney text {
	color: #ff0000;
	font-weight: bold;
	font-size: 50rpx;
}
</style>
