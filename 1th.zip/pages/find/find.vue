<template>
	<view class="find">
		<view class="scroll shadow-warp">
			<uni-notice-bar
				scrollable="true"
				single="true"
				showIcon="true"
				@click.stop="clickviews"
				speed="50"
				background-color="#F6F8FA"
				text="1在投保人在填写投保单时，销售人员应向投保人依次解释投保单上各项内容的意义和填写要求 2说明填写投保单的注意事项，帮助投保人阅读并充分理解投保资料，提醒投保人认真阅读“投保须知”和条款等内容。"
			></uni-notice-bar>
		</view>
		<view class="hot">
			<view class="scrollview">
				<text class="title">精选专区</text>
				<scroll-view class="scroll-view_H" scroll-x="true">
					<view class="bg-olive contentTab demo1" @click="gotoinsure(1)">
						<view class="textall">重疾险</view>
						<view class="textall textone">5万保额</view>
						<view class="bg-gradual-orange textall texttwo">开启保障</view>
					</view>
					<view class="bg-olive contentTab demo2" @click="gotoinsure(2)">
						<view class="textall">航空意外险</view>
						<view class="textall textone">100万保额</view>
						<view class="bg-gradual-orange textall texttwo">免费领取</view>
					</view>
					<view class="bg-olive contentTab demo3" @click="gotoinsure(3)">
						<view class="textall">驾乘意外险</view>
						<view class="textall textone">1万保额</view>
						<view class="bg-gradual-orange textall texttwo">开启保障</view>
					</view>
				</scroll-view>
			</view>
		</view>
		<view class="bg-white flex-sub radius shadow-warp">
			<image src="https://image.weilanwl.com/gif/loading-white.gif" mode="aspectFit" class="gif-white response" style="height:60upx"></image>
		</view>
		<view class="newinsur">
			<text class="title">新保险</text>
			<view class="claimsflex">
				<view class="claimstop" @click="clicknews(newinsure[index].title)" v-for="(item, index) in newinsure" :key="index">
					<text class="bg-olive claimsTab claimstyle">
						<text class="cuIcon-evaluate_fill text-orange  evaicon"></text>
						{{ item.title }}
					</text>
				</view>
			</view>
		</view>
		<!-- 理赔 -->
		<view class="claims">
			<text class="title">理赔案例</text>
			<view class="claimsleft">
				<text class="bg-olive claimsTab" @click="clickclaim(1)">
					真实理赔案例
					<text class="cuIcon-creative text-orange creicon"></text>
				</text>
				<text class="bg-olive claimsTab" @click="clickclaim(2)">
					理赔小技巧
					<text class="cuIcon-creative text-orange creicon"></text>
				</text>
			</view>
		</view>
	</view>
</template>

<script>
import uniNoticeBar from '@/components/uni-notice-bar/uni-notice-bar.vue';
export default {
	components: { uniNoticeBar },
	data() {
		return {
			newinsure: [{ title: '1分投保全家受益' }, { title: '社保补充,保自费药' }, { title: '60岁以上投保必看' }, { title: '1000元轻松配备' }],
			scrollTop: 0,
			old: {
				scrollTop: 0
			}
		};
	},
	onLoad() {},
	methods: {
		scroll: function(e) {
			console.log(e);
			this.old.scrollTop = e.detail.scrollTop;
		},
		gotoinsure() {
			// uni.showModal({
			// 	content: '暂未开放',
			// 	showCancel: false
			// });
			uni.navigateTo({
				url:'geratarea/greatList'
			})
		},
		clickviews() {
			uni.showModal({
				content: '暂时无法查看消息',
				showCancel: false
			});
		},
		clicknews(e) {
			uni.navigateTo({
				url: './newinsure/newinsure?title=' + encodeURIComponent(JSON.stringify(e))
			});
		},
		clickclaim(e) {
			if (e == 1) {
				uni.navigateTo({
					url: './claim/realClaim'
				});
			} else {
				uni.navigateTo({
					url: './claim/skillClaim'
				});
			}
		}
	}
};
</script>

<style>
.find {
	width: 100%;
	/* margin: 0 20rpx; */
}
.title {
	display: block;
	margin-left: 20rpx;
	height: 60rpx;
	line-height: 40rpx;
	padding-top: 20rpx;
}
.scroll {
	margin-top: 20rpx;
	margin-left: 20rpx;
	margin-right: 20rpx;
}
.scroll-view_H {
	/* 文本不会换行，文本会在在同一行上继续，直到遇到 <br> 标签为止。 */
	white-space: nowrap;
	width: 100%;
}

.scrollview {
	position: relative;
	height: 300rpx;
	overflow: hidden;
}
.contentTab {
	position: relative;
	display: inline-block;
	width: 300rpx;
	height: 200rpx;
	margin-left: 20rpx;
	border-radius: 20rpx;
	padding: 20rpx;
}
.textall {
	display: inline-block;
	width: 100%;
	color: #ffffff;
}
.textone {
	position: absolute;
	left: 20rpx;
	top: 80rpx;
}
.texttwo {
	/* display: inline-block; */
	position: absolute;
	left: 100rpx;
	top: 140rpx;
	width: 180rpx;
	height: 50rpx;
	border-radius: 20rpx;
	color: #ffffff;
	font-size: 30rpx;
	text-align: center;
	line-height: 50rpx;
}

/*  */
.newinsur {
	padding: 0 20rpx;
	margin-bottom: 30rpx;
	width: 100%;
	/* display: flex; */
}
/* 理赔 */
.claims {
	/* position: relative; */
	/* height: 150rpx; */
	/* padding: 0 20rpx; */
}
.claimstyle {
	margin: 0rpx 20rpx;
	font-size: 30rpx;
	line-height: 200rpx !important;
}
.claimstop {
}
.claimsflex {
	display: flex;
	flex-wrap: wrap;
	justify-content: space-around;
}

.claimsleft {
	display: inline-flex;
	justify-content: space-around;
	width: 100%;
	height: 150rpx;
}
.claimsTab {
	position: relative;
	display: inline-block;
	height: 140rpx;
	width: 336rpx;
	text-align: center;
	line-height: 140rpx;
	border-radius: 20rpx;
	margin: 10rpx 0;
}
.evaicon {
	position: absolute;
	font-size: 40rpx;
	left: 148rpx;
	top: -56rpx;
}
.creicon {
	font-size: 40rpx;
	margin-left: 20rpx;
}
</style>
