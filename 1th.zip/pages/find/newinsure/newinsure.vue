<template>
	<view class="caselist">
		<view class="header">
			<text class="title">{{title}}</text>
			<text class="time_pub text-gray">2020-03-12 15:26 · {{pub}}</text>
		</view>
		<view class="content">
			<text>
				这时候，王先生突然想起一张保单—尊享e生，他之前为妈妈投保的。详细查看保险责任后，他发现一个忽略的小服务—医疗垫付，这是尊享e生的免费增值服务之一，满足条件可以提前垫付医药费！
				
				抱着试一试的心态，王先生拨打了众安24小时服务电话，希望预先垫付一笔医药费。没想到，第二天服务人员就联系了他，并在预定时间赶到医院，上门收集垫付相关资料。
				
				经审核满足条件后，医疗垫付开始了，前后3个多月的时间，尊享e生总计垫付14次，垫付金额高达101.86万元。
				
				靠着这一笔笔垫付款，贾女士熬过了3个月的抢救期，肺部感染情况基本被控制，并成功出院：
				
				4月15日，垫付5000元；
				
				4月19日，垫付10万元；
				
				4月28日，垫付10万元；
				
				5月6日，垫付5万元；
				
				5月15日，垫付10万元；
				
				......
				
				7月23日，垫付10万元；
				
				7月24日，垫付8.92万元；
				
				7月26日，贾女士出院，服务人员协同办理后续理赔。

				回访过程中，王先生说，保险提供了巨大的帮助，非常非常感谢。
				<!-- ../../../static/img/banner1.jpg -->
				<image :src="imgurl" mode=""></image>

				再来了解一下医疗垫付服务
	
				医疗险是报销性质，先看病后报销，实报实销，即看完病付过钱后，拿着病历和发票报销，之前要么自己拿钱付，要么找人借钱付，如果治疗费用太高，一般家庭很难承担。

				为解决这一痛点，尊享e生免费推出医疗垫付，住院垫付，出院报销，垫付额度最多600万，有了这项服务，基本不用担心没钱看病！目前，医疗垫付服务覆盖全国83个城市，超过2000家医院，1个工作日内专人上门收取申请资料，提交完整材料后，最快1个工作日审核答复。

			</text>
	<view class="share">
		<button @click="share" type="primary" size="mini" class="cu_btn round line-green">分析给好友</button> 
	</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				title:'',
				pub : '',
				imgurl:''
			}
		},
		onLoad:function(option){
			// let ndata = 
			this.title = JSON.parse(decodeURIComponent(option.title));
		},
		methods: {
			share(){
			uni.share({
			    provider: "weixin",
			    scene: "WXSceneSession",
			    type: 1,
			    summary: "我正在使用HBuilderX开发uni-app，赶紧跟我一起来体验！",
			    success: function (res) {
			        console.log("success:" + JSON.stringify(res));
			    },
			    fail: function (err) {
			        console.log("fail:" + JSON.stringify(err));
			    }
			});
			}
		}
	}
</script>

<style>
	.caselist{
		padding: 20rpx 20rpx;
		padding-bottom: 110rpx;
	}
	.header{
		
	}
	.title{
		display: block;
		font-size: 36rpx;
		font-weight: bold;
		margin-bottom: 10rpx;
	}
	.time_pub{
		font-size: 20rpx;
		
	}
	.content{
		overflow: hidden;
	}
	.content image{
		width: 100%;
		margin: 10rpx 0rpx;
	}
	.share{
		position: fixed;
		bottom: 0rpx;
		left: 0rpx;
		margin-right: 20rpx;
		width: 100%;
		height: 100rpx;
		text-align: center;
	}

</style>
