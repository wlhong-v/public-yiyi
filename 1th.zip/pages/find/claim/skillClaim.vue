<template>
	<view class="mainmore">
		<view class="banner">
			<view class="bannerimg"><image src="../../../static/img/banner3.jpg" mode="center" style="width: 100%; height: 200rpx;"></image></view>
			<view class="title">
				<text>如何理赔最有保障？这些小技巧你一定不要错过</text>
				<text>理赔技小技巧</text> 
			</view>
		</view>
		<view class="box">
			<view class="main_content" v-for="(item, index) in views" :key="index" @click="checkDemo(index+1)">
				<text class="contenttitle">{{item.title}}</text>
				<view class="contimage"><image :src="item.imgurl" mode="widthFix" style="width: 200rpx; height: 150rpx;"></image></view>
				<view class="publisher">
					<text class="">{{item.pub}}</text>
					<!-- <text class="publisher1 iconfont  iconxinxi">79999</text> -->
					<text class="publisher1 iconfont iconyanjing">{{item.see}}</text>
				</view>
			</view>
			
		</view>

		<!-- NO more -->
		<view class="nomore">我是有底线的.....</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			views:[
				{title:'关于保险理赔的误区，你都经历过吗',pub:'百保君',see:'234',imgurl:'../../../static/img/claim1.jpg'},
				{title:'没在指定医院就医？这样做小心保险真的不赔',pub:'众安健康',see:'187',imgurl:'../../../static/img/claim2.jpg'},
				{title:'记住这几点，让医疗险理赔变得更更更更更简单!',pub:'百保君',see:'1681',imgurl:'../../../static/img/claim3.jpg'},
				{title:'购买保险时出现这6中情况，真的不赔',pub:'百保君',see:'1750',imgurl:'../../../static/img/claim4.jpg'},
				{title:'保险理赔需要什么条件',pub:'百保君',see:'1750',imgurl:'../../../static/img/claim1.jpg'},
				{title:'保险理赔没有想象中难，这7大误区牢记',pub:'百保君',see:'1750',imgurl:'../../../static/img/claim3.jpg'},
				{title:'车险理赔难?叫你一招“马上赔”，最快三分钟结案',pub:'百保君',see:'1750',imgurl:'../../../static/img/claim2.jpg'},
				]
		};
	},
	components: {},
	methods: {
		checkDemo(e) {
			let detail ={
				ntitle : this.views[e-1].title,
				npub : this.views[e-1].pub,
				nimg : this.views[e-1].imgurl
			} 
			uni.navigateTo({
				url:'./caselist?detail='+ encodeURIComponent(JSON.stringify(detail))
			})
		}
	},
	onLoad(e) {}
};
</script>

<style>
.mainmore {
	width: 100%;
}
.banner {
	position: relative;
	margin: 0 auto;
}

.bannerimg {
	/* background-image: url(../../static/img/banner2.jpg) ; */
	height: 200rpx;
	width: 100%;
	position: absolute;
	z-index: -1;
	overflow: hidden;
}
.title {
	margin: 0 auto;
	padding: 30rpx 20rpx;
	position: relative;
	top: 150rpx;
	height: 210rpx;
	width: 84%;
	border-radius: 20rpx;
	background-color: #ffffff;
	text-align: center;
	box-shadow: 0 4rpx 10rpx 4rpx #f1f1f1;
	font-size: 30rpx;
}
.title text:nth-child(1) {
	display: block;
	font-size: 40rpx;
	margin-bottom: 20rpx;
}
.title text:nth-child(2) {
	display: block;
	font-size: 24rpx;
	color: #969896;
}

/* 内容部分 */
.box {
	margin-top: 200rpx;
	width: 100%;
	margin-left: auto;
	margin-right: auto;
}
.main_content {
	position: relative;
	margin: 20rpx 20rpx;
	width: 90%;
	height: 190rpx;
	padding: 20rpx;
	background-color: #ffffff;
	border-radius: 20rpx;
	border-bottom: 1rpx solid #e9e9e9;
	border-top: 1rpx solid #e9e9e9;
}
.contimage {
	position: absolute;
	top: 20rpx;
	right: 0rpx;
	width: 200rpx;
	height: 150rpx;
	overflow: hidden;
	border-radius: 20rpx;
	background-color: #1afa29;
}
.contenttitle {
	display: block;
	width: 400rpx;
	font-size: 36rpx;
}
.publisher {
	position: absolute;
	top: 120rpx;
	left: 40rpx;
	display: inline-flex;
	justify-content: flex-start;
	width: 100%;
	margin-top: 24rpx;
	font-size: 26rpx;
	color: #969896;
}

.publisher text {
	display: inline-block;
	margin-right: 40rpx;
}
.publisher1 {
	position: relative;
	font-size: 26rpx;
}
.icon_eye {
	position: absolute;
	left: -26rpx;
	top: 8rpx;
}
.nomore {
	width: 100%;
	height: 30rpx;
	text-align: center;
	line-height: 30rpx;
	font-size: 30rpx;
	color: #e9e9e9;
	margin-bottom: 20rpx;
}
</style>


</style>
