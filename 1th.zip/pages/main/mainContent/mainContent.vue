<template>
	<view class="main_content">
		<view class="main_tit">
			<text class="main_title">{{title}}</text>
			<!-- <view class="bg-white flex-sub radius main_titleBox">
				<image src="https://image.weilanwl.com/gif/loading-white.gif" mode="aspectFit" class="gif-white response" style="height:60upx"></image>
				
			</view> -->
			<view class="main_views text-gray">
				<text>2019-10-29</text>
				<text class="cuIcon-titles text-gray"></text>
				<text>1290阅读</text>
			</view>
		</view>
		<view class="content_views">
			内容部分 风靡全球，科学搭配的标准普尔四个账户知多少： 第一部分是现金账户占比40%： 经常性，随时要花的钱，一般是放在现金账户里。
			比如，日常消费吃穿行都可以用这部分储蓄，建议大家放在银行活期，支付宝的余额宝里，货币基金等，T+0或T+1即刻到账。
			<image src="../../../static/img/banner2.jpg" mode=""></image>
			灵活性的不足，剁手在不经意间，花钱如流水，收益几乎接近0，忠告自控力差的人不采用这种方式。 第二类账户：风险保障类账户即保命的钱
			比如一些突发意外疾病状况引起的一些大的开销，说到底就是防止“辛辛苦苦几十年，一病回到解放前”从我们身上发生。
			年轻人用意外险，重疾，医疗和寿险来规避人生风险，保费投入最高占个人收入的20%。 第三类账户：让钱生钱的投资账户 这类产品的特点收益高，风险也大，胆小者误入。
			<image src="../../../static/img/missBanner.png" mode=""></image>
			买股票可以几个涨停，但是也可以让你坐过山车，亏得让你只剩裤衩， 定投基金稳定，但是周期长；
			<view class="text-black text-bold text-xl"><text>01开源节流</text></view>
			投资性房产要选地段，地段，地段，而且还要跟党走，看风险， 以上投资比例最高占个人资产的30%。 第四类账户：理财账户，也可以叫保本升值账户
			年金，自益信托，PPP债券，基金定投等。 这类产品的特点长期，安全，稳健，复利增值。 既可用做子女教育，又可做父母养老和自己的养老规划等。
			<view class="text-black text-bold text-xl"><text>02投资</text></view>
			比如：基金定投，虽然说有风险，但是通过定时定额，养成强制储蓄习惯，也是可以平滑部分市场的风险。
			年金险同样是定时定额的强制储蓄账户工具。保证本金安全，锁定终身4.025%收益，确保在未来有一笔确定的教育和养老钱可以用。 投入比例占个人资产的40%左右。
			这四个账户可以指导几乎每个人规划自己的资产，而当你选择适合自己的投资理财工具时也一定要考虑：安全性，流动性，收益性。
			<view class="text-black text-bold text-xl"><text>03股票</text></view>
			有人说，这四个账户的比例很难执行，没关系，四个账户也不是固定不变。 如果你不懂股票，房产投资，可以各个账户比例缩减，可以转投稳妥些账户。
			一定要想清楚：我能承受多大的损失风险？什么时间会用到，想要多久变现？ 最后，建议是每个家庭都要有这四个账户，然后根据自己的风险偏好去选择合适的投资比例。
		</view>
		<view class="main_footer text-gray">
			<view class="btn">
				<view class="btn_right" @click="showzan">
					<text class="cuIcon-appreciate lg main_icon" :class="islike ? 'text-yellow' : ' text-gray'"></text>
					<view>
						<text>{{ zanNumber }}</text>
					</view>
				</view>
			</view>
			<view class="btn">
				<view class="btn_right" @click="showcollection">
					<text class="cuIcon-favor lg  main_icon" :class="iscollection ? 'text-yellow' : ' text-gray'"></text>
					<view><text class="btn_coll">收藏</text></view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			title:'',
			zanNumber: 3,
			cont:"基金定投，虽然说有风险，但是通过定时定额，养成强制储蓄习惯",
			islike: false,
			iscollection: false,
			phone:''
		};
	},
	onLoad: function(option) {
		//option为object类型，会序列化上个页面传递的参数
		 //打印出上个页面传递的参数。
		this.title = JSON.parse(option.title);
		this.getcoll(1)
	},
	methods: {
		getcoll(e){
			var phone = uni.getStorageSync('username')
			this.phone = phone
			this.$axios
			.get('http://127.0.0.1:3000/getcoll',{
				params:{
					phone:phone
				}
			})
			.then( res => {
				if(res.data.message[0].coll_title==this.title){
					this.iscollection=true
				}
			})
			.catch(err=>{
				console.log(err)
			})
		},
		showzan() {
			if (!this.islike) {
				this.zanNumber += 1;
				this.islike = true;
			} else {
				this.islike = false;
				this.zanNumber -= 1;
			}
		},
		showcollection() {
			if (!this.iscollection) {
				// 日期》数据库自动获取
				this.iscollection = true;
				this.$axios
					.get('http://127.0.0.1:3000/addcoll',{
						params:{
							phone:this.phone,
							title:this.title,
							zan:this.zanNumber,
							iscoll:'0',
							cont:this.cont
							}
					})
					.then(res => {
						console.log('收藏成功');
					})
					.catch(err => {
						console.log('请求失败' + err);
					});
				
			} else {
				this.iscollection = false;
				this.$axios
					.get('http://127.0.0.1:3000/delcoll',{
						// 携带的参数，在url中解析
						params:{　　　
						　　　　 phone: this.phone,
								title:this.title
						}
					})
					.then(res => {
						console.log('取消收藏成功');
					})
					.catch(err => {
						console.log('取消收藏失败' );
					});	
				
			}
		}
	}
};
</script>

<style>
.main_content {
	width: 100%;
	padding: 10rpx 20rpx 0 20rpx;
}
/* 时间、点赞、阅读量 */
.main_title {
	font-size: 40rpx;
	font-weight: bold;
}

.main_views {
	top: 0;
	height: 60rpx;
	width: 100%;
	padding: 10rpx 0;
}
/* 内容部分 */
.content_views {
	padding-bottom: 130rpx;
	/* 	text-align: justify; 使文本左右对齐  */
	text-align: justify;
}
.content_views image {
	display: block;
	margin: 0 auto;
	padding: 20rpx;
}

/* 底部固定 */
.main_footer {
	position: fixed;
	bottom: 0rpx;
	height: 100rpx;
	width: 100%;
	background-color: #ffffff;
	display: inline-flex;
}

.btn {
	height: 100%;
	width: 50%;
	font-size: 40rpx;
	text-align: center;
}
.btn_coll {
	font-size: 30rpx;
}
.btn_right {
	width: 100rpx;
	height: 100%;
	margin: 0 auto;
}
</style>
