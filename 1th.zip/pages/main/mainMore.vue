<template>
	<view class="mainmore">
		<view class="banner">
			<view class="bannerimg"><image src="../../static/img/findTab2.jpg" mode="center" style="width: 100%; height: 200rpx;"></image></view>
			<view class="title">
				<text>小白投保入门指南</text>
				<text>买保险，不是一件容易的事儿，但也没有你想象中的那么简单。这里汇总了一批保险小白入门必读干货，快去看看吧！</text>
			</view>
		</view>
		<view class="box">
			<view class="main_content" v-for="(item, index) in 10" :key="index" @click="checkDemo(index+1)">
				<text class="contenttitle">是的法师法师是的法师法师是的法师法师</text>
				<view class="contimage"><image src="../../static/img/banner2.jpg" mode="widthFix" style="width: 200rpx; height: 150rpx;"></image></view>
				<view class="publisher">
					<text class="">众安头条发布</text>
					<text class="publisher1 iconfont  iconxinxi">79999</text>
					<text class="publisher1 iconfont iconyanjing">16662</text>
				</view>
			</view>
		</view>

		<!-- NO more -->
		<view class="nomore">我是有底线的.....</view>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	components: {},
	methods: {
		checkDemo(e) {
			uni.showModal({
				title:'访问了第' + e + '个选项卡',
				content:'具体内容暂未发布' ,
				showCancel: false
			});
		}
	},
	onLoad(e) {}
};
</script>

<style>
.mainmore {
	width: 100%;
}
.banner {
	position: relative;
	margin: 0 auto;
}

.bannerimg {
	/* background-image: url(../../static/img/banner2.jpg) ; */
	height: 200rpx;
	width: 100%;
	position: absolute;
	z-index: -1;
	overflow: hidden;
}
.title {
	margin: 0 auto;
	padding: 30rpx 20rpx;
	position: relative;
	top: 150rpx;
	height: 210rpx;
	width: 84%;
	border-radius: 20rpx;
	background-color: #ffffff;
	text-align: center;
	box-shadow: 0 4rpx 10rpx 4rpx #f1f1f1;
	font-size: 30rpx;
}
.title text:nth-child(1) {
	display: block;
	font-size: 40rpx;
	margin-bottom: 20rpx;
}
.title text:nth-child(2) {
	display: block;
	font-size: 24rpx;
	color: #969896;
}

/* 内容部分 */
.box {
	margin-top: 200rpx;
	width: 100%;
	margin-left: auto;
	margin-right: auto;
}
.main_content {
	position: relative;
	margin: 20rpx 20rpx;
	width: 90%;
	height: 190rpx;
	padding: 20rpx;
	background-color: #ffffff;
	border-radius: 20rpx;
	border-bottom: 1rpx solid #e9e9e9;
	border-top: 1rpx solid #e9e9e9;
}
.contimage {
	position: absolute;
	top: 20rpx;
	right: 0rpx;
	width: 200rpx;
	height: 150rpx;
	overflow: hidden;
	border-radius: 20rpx;
	background-color: #1afa29;
}
.contenttitle {
	display: block;
	width: 400rpx;
	font-size: 36rpx;
}
.publisher {
	display: inline-flex;
	justify-content: flex-start;
	width: 100%;
	margin-top: 24rpx;
	font-size: 26rpx;
	color: #969896;
}

.publisher text {
	display: inline-block;
	margin-right: 40rpx;
}
.publisher1 {
	position: relative;
	font-size: 26rpx;
}
.icon_eye {
	position: absolute;
	left: -26rpx;
	top: 8rpx;
}
.nomore {
	width: 100%;
	height: 30rpx;
	text-align: center;
	line-height: 30rpx;
	font-size: 30rpx;
	color: #e9e9e9;
	margin-bottom: 20rpx;
}
</style>
