<template>
	<view class="content">
		<!-- 轮播图 -->
		<uni-swiper-dot :info="info" :current="current" field="content" :mode="mode" :dotsStyles="dotsStyles">
			<swiper class="swiper-box" @change="change">
				<swiper-item v-for="(item, index) in info" :key="index">
					<image :src="item.url" style="width: 100%; height: 100%;"></image>
					<!-- <view class="swiper-item">{{ item.content }}</view> -->
				</swiper-item>
			</swiper>
		</uni-swiper-dot>

		<!-- 险种 -->
		<view class="uni-flex ">
			<view class="flex-item " @click="tabClick(1)">
				<view class="iconfont iconertong"></view>
				<view class=""><text>少儿意外险</text></view>
			</view>
			<view class="flex-item " @click="tabClick(2)">
				<view class="iconfont iconcanjiren"></view>
				<view class=""><text>长期重疾险</text></view>
			</view>
			<view class="flex-item " @click="tabClick(3)">
				<view class="iconfont iconyiwaixian"></view>
				<view class=""><text>人身意外险</text></view>
			</view>
			<view class="flex-item " @click="tabClick(4)">
				<view class="iconfont iconjiache"></view>
				<view class=""><text>驾车意外险</text></view>
			</view>
		</view>

		<!-- 信息列表 -->
		<view class="list">
			<view class="listTitle">
				<image src="../../static/img/views.png" style="width: 26rpx; height: 26rpx;" mode=""></image>
				<text class="titLfet" @click="requst">保险小知识</text>
				<image class="titRight" src="../../static/img/toRight.png" style="width: 36rpx; height: 36rpx;" @click="clickMore"></image>
			</view>
			<view class="listContent">
				<view class="listText" v-for="(item, index) in views" :key="index" @click="checkDemo(index+1)">
					<image :src="item.imgUrl" style="width: 180rpx; height: 180rpx;" mode="" @click="clickTab(index)"></image>
					<view class="textCon">
						<text class="textTit" @click="clickTab(index)">{{ item.title }}</text>
						<text class="textView" @click="clickTab(index)">{{ item.explain }}</text>
					</view>
				</view>
			</view>
		</view>

		<!-- 加载更多 -->
		<!--  <view v-if="hasLogin" class="hello">
            <view class="title">
                您好 {{userName}}，您已成功登录。
            </view>
            <view class="ul">
                <view>这是 uni-app 带登录模板的示例App首页。</view>
                <view>在 “我的” 中点击 “退出” 可以 “注销当前账户”</view>
            </view>
        </view>
        <view v-if="!hasLogin" class="hello">
            <view class="title">
                您好 游客。
            </view>
            <view class="ul">
                <view>这是 uni-app 带登录模板的示例App首页。</view>
                <view>在 “我的” 中点击 “登录” 可以 “登录您的账户”</view>
            </view>
        </view> -->
	</view>
</template>

<script>
import { mapState } from 'vuex';
// import uniSwiperDot from '../../components/uni-swiper-dot/uni-swiper-dot.vue';
import uniSwiperDot from '../../components/uni-swiper-dot/uni-swiper-dot.vue';

export default {
	components: {
		uniSwiperDot
	},
	props: {},
	data() {
		return {
			isCard: false,
			// 数据长度指定指示点数量
			info: [
				{
					url: '../../static/img/banner1.jpg'
				},
				{
					url: '../../static/img/banner2.jpg'
				},
				{
					url: '../../static/img/banner3.jpg'
				},
				{
					url: '../../static/img/banner4.jpg'
				}
			],
			current: 0,
			mode: 'default',
			// 设置指示点样式
			dotsStyles: {
				backgroundColor: 'rgba(95,205,250, .3)',
				color: '#fff',
				//选中的指示点颜色
				selectedBackgroundColor: 'rgba(16,180,248, .3)'
			},
			// 列表数据
			views: [
				{
					viewsId: '1',
					title: '保险小白白1',
					imgUrl: '../../static/img/list_1.jpg',
					explain: '保险专家手 ,	把手教你如何挑选适合自己的保险 保险专家 手把手教你如何挑选适合自己的保险 保险专家手把手教你如何挑选适合自己的保险 自己的保险保险专niaho'
				},
				{
					viewsId: '2',
					title: '保险小白白2',
					imgUrl: '../../static/img/list_1.jpg',
					explain: '保险专家手 ,	把手教你如何挑选适合自己的保险 保险专家 手把手教你如何挑选适合自己的保险 保险专家手把手教你如何挑选适合自己的保险 自己的保险保险专niaho'
				},
				{
					viewsId: '3',
					title: '保险小白白3',
					imgUrl: '../../static/img/list_1.jpg',
					explain: '保险专家手 ,	把手教你如何挑选适合自己的保险 保险专家 手把手教你如何挑选适合自己的保险 保险专家手把手教你如何挑选适合自己的保险 自己的保险保险专niaho'
				},
				{
					viewsId: '4',
					title: '保险小白白4',
					imgUrl: '../../static/img/list_1.jpg',
					explain: '保险专家手 ,	把手教你如何挑选适合自己的保险 保险专家 手把手教你如何挑选适合自己的保险 保险专家手把手教你如何挑选适合自己的保险 自己的保险保险专niaho'
				},
				{
					viewsId: '5',
					title: '保险小白白5',
					imgUrl: '../../static/img/list_1.jpg',
					explain: '保险专家手 ,	把手教你如何挑选适合自己的保险 保险专家 手把手教你如何挑选适合自己的保险 保险专家手把手教你如何挑选适合自己的保险 自己的保险保险专niaho'
				},
				{
					viewsId: '6',
					title: '保险小白白6',
					imgUrl: '../../static/img/list_1.jpg',
					explain: '保险专家手 ,	把手教你如何挑选适合自己的保险 保险专家 手把手教你如何挑选适合自己的保险 保险专家手把手教你如何挑选适合自己的保险 自己的保险保险专niaho'
				}
			]
		};
	},
	methods: {
		// 滑动轮播图
		change(e) {
			this.current = e.detail.current;
		},
		// 点击格子
		tabClick(e) {
			console.log(e);
			switch (e) {
				case 1:
					uni.navigateTo({
						url: '../insure/child'
					});
					break;

				case 2:
					uni.navigateTo({
						url: '../insure/strichen'
					});
					break;

				case 3:
					uni.navigateTo({
						url: '../insure/miss'
					});
					break;

				case 4:
					uni.navigateTo({
						url: '../insure/drive'
					});
					break;
			}
		},
		// 查看更多（箭头）
		clickMore() {
			console.log('点击查看更多');
			uni.navigateTo({
				url: '../main/mainMore?id=1'
			});
		},
		// 列表
		clickTab(e) {
			console.log('点击了第' + e + '个列表');
		},
		// 箭头更多跳转
		jumpMore(e) {
			console.log(e);
			uni.navigateTo({
				url: '../main/mainMore'
			});
		},
		// 点击选项卡内容
		checkDemo(e) {
			var posttitle =this.views[e-1].title;
			// console.log(posttitle);
			uni.navigateTo({
				// 向mainContent页面传递标题
				// 要把参数里面不能通过url传递的字符进行编码encodeURIComponent(JSON.stringify(posttitle))
				url:'./mainContent/mainContent?title=' + encodeURIComponent(JSON.stringify(posttitle))
			})
		},
		requst() {
			console.log('发送请求');
			uni.request({
				url: ' mongodb://127.0.0.1:27017',
				method: 'GET',
				success: res => {
					console.log(res);
					// this.text = 'request success';
				},
				fail: err => {
					console.log(err);
				}
			});
		}
	},

	// 弹窗，强制先登录
	computed: mapState(['forcedLogin', 'hasLogin', 'userName']),
	// 下拉刷新
	onPullDownRefresh() {
		// 模拟刷新追加数据
		this.views.push({
			viewsId: '7',
			title: '保险小heihei',
			imgUrl: '../../static/img/list_1.jpg',
			explain: '保险专家手 ,	把手教你如何挑选适合自己的保险 保险专家 手把手教你如何挑选适合自己的保险 保险专家手把手教你如何挑选适合自己的保险 自己的保险保险专niaho'
		});
		setTimeout(() => {
			uni.stopPullDownRefresh();
			console.log('停止下拉刷新');
		}, 1000);
	},
	// 上拉触底
	onReachBottom() {
		console.log('触底了');
	},
	onTabItemTap(res) {
		console.log(res.text);
	},

	onLoad() {
		// 自动刷新首页数据
		setTimeout(() => {
			console.log('下拉刷新');
		}, 1000);
		// uni.startPullDownRefresh();
		//      if (!this.hasLogin) {
		//          uni.showModal({
		//              title: '未登录',
		//              content: '您未登录，需要登录后才能继续',
		//              /**
		//               * 如果需要强制登录，不显示取消按钮
		//               */
		//              showCancel: !this.forcedLogin,
		//              success: (res) => {
		//                  if (res.confirm) {
		// /**
		//  * 如果需要强制登录，使用reLaunch方式
		//  */
		//                      if (this.forcedLogin) {
		//                          uni.reLaunch({
		//                              url: '../login/login'
		//                          });
		//                      } else {
		//                          uni.navigateTo({
		//                              url: '../login/login'
		//                          });
		//                      }
		//                  }
		//              }
		//          });
		//      }
	}
};
</script>

<style>
.iconfont {
	font-size: 90rpx;
	color: #1AFA29;
}
.content {
	background-color: #ffffff;
	color: #333333;
	padding: 0rpx;
}
.hello {
	display: flex;
	flex: 1;
	flex-direction: column;
}

.title {
	color: #8f8f94;
	margin-top: 50upx;
}

.ul {
	font-size: 30upx;
	color: #8f8f94;
	margin-top: 50upx;
}

.ul > view {
	line-height: 50upx;
}

.uni-flex {
	display: flex;
	flex-wrap: wrap;
	margin-top: 20rpx;
}
/* 险种选项卡 */
.flex-item {
	text-align: center;
	width: 25%;
	height: 150rpx;
	font-size: 30rpx;
	/* background-color: #0077aa; */
}

.tabImg {
	margin: 0 30rpx;
	width: 100rpx;
	height: 100rpx;
}
/* 保险信息 */
.list {
	width: 100%;
	height: 100%;
	background-color: #ffffff;
	border-radius: 10rpx;
	padding-top: 30rpx;
}
.listTitle {
	line-height: 50rpx;
	border-bottom: 1rpx solid #cccccc;
	margin: 0 20rpx;
}
.titLfet {
	/* float: left; */
	margin-left: 10rpx;
}
.titRight {
	margin-top: 10rpx;
	float: right;
}
/* 列表 */
.listContent {
	margin-top: 10rpx;
	width: 100%;
	height: 180rpx;
}
.listText {
	position: relative;
	padding-left: 20rpx;
	margin-top: 20rpx;
	margin-right: 20rpx;
	border-bottom: 1rpx solid #f5f2f0;
	padding-bottom: 20rpx;
}
.textCon {
	width: 500rpx;
	position: absolute;
	padding-left: 20rpx;
	/* 设置例表内容的行距 */
	line-height: 40rpx;
	top: 0rpx;
	left: 200rpx;
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-box-orient: vertical;
	-webkit-line-clamp: 3;
}
.textTit {
	display: block;
	font-weight: bold;
	font-size: 30rpx;
}
.textView {
	font-weight: 400;
	font-size: 24rpx;
	color: #99999;
}
</style>
