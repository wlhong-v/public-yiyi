<template>
	<view class="claim">
		<view class="claim-list  bg-gradual-blue shadow-warp" v-for="(item,index) in list" :key="index" @longtap="change(index)">
			<text class="cuIcon-medalfill claim-icon text-blue"></text>
			<view class="">申 请 号:{{ item.insure_id }}</view>
			<view class="">申请人姓名:{{ item.insure_username }}</view>
			<view class="">购买保险日期:{{ item.insure_time }}</view>
		</view>
		<!-- 添加框 -->
		<view class="get-claim padding solid shadow bg-white" @click="getclaim"><text class="cuIcon-add lg text-gray text-xsl text-blue text-center"></text></view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			list: [],
			phone:''
		};
	},
	onShow: function() {
		this.showClaim();
	},
	mounted: function() {},
	methods: {
		getclaim() {
			uni.redirectTo({
				url: './claimlist/claimlist'
			});
		},
		// 取消理赔
		change(e) {
			// 删除的索引
			console.log(this.list[e].insure_id)
			var id = this.list[e].insure_id
			uni.showModal({
				// e选择索引
				content: '确定删除此条理赔?',
				success: res => {
					if (res.confirm) {
						this.$axios
							.get('http://127.0.0.1:3000/delcaim',{
								// 携带的参数，在url中解析
								params:{　　　
								　　　　 id: id
								}
							})
							.then(res => {
								console.log('删除成功');
								this.list=[];
								this.showClaim();
							})
							.catch(err => {
								console.log('删除失败' + err);
							});			
						
					} else {
						console.log('取消删除');
					}
				}
			});
		},
		// 展示理赔列表
		showClaim() {
			this.phone = uni.getStorageSync('username')
			// 根据账户请求数据
			this.$axios
				.get('http://127.0.0.1:3000/getclaimlist', {
					params: {
						phone: this.phone
					}
				})
				.then(res => {
					console.log("请求成功")
					this.list = res.data.message;
				})
				.catch(err => {
					console.log("请求失败")
					console.log(err);
				});
		}
	}
};
</script>

<style>
.claim {
	width: 100%;
	padding: 0 20rpx;
}
.get-claim {
	width: 180rpx;
	height: 180rpx;
	margin: 0 auto;
	margin-top: 180rpx;
}
.claim-list {
	position: relative;
	padding: 20rpx 20rpx;
	line-height: 54rpx;
	width: 100%;
	height: 200rpx;
	border-radius: 20rpx;
	margin-top: 28rpx;
}
.claim-icon {
	position: absolute;
	font-size: 60rpx;
	left: 600rpx;
}
</style>
