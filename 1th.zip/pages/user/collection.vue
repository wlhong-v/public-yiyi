<template>
	<view class="collection">
		<view class="coll-list" v-if="isshow">
			<view class="bg-gradual-blue shadow-warp list" v-for="(item, index) in list" :key="index" @longtap="change(index)">
				<text class="title ">{{ item.coll_title }}</text>
				<text class="price">点赞数{{ item.coll_zan }}</text>
				<text class="brief">{{ item.coll_cont }}</text>
				<text class="time">{{ item.coll_time }}</text>
			</view>
		</view>
		<view class="showText" v-if="!isshow"><text>您还没有收藏任何信息。。。快去查阅收藏吧！</text></view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			list: [],
			phone: '',
			isshow: false
		};
	},
	onShow: function() {
		this.add(1);
	},

	methods: {
		// 获取保险收藏数据、渲染页面
		add(e) {
			var Uphone = uni.getStorageSync('username');
			if (e == 1) {
				this.$axios
					.get('http://127.0.0.1:3000/getcoll', {
						params: {
							phone: Uphone
						}
					})
					.then(res => {
						console.log('请求成功');
						console.log(res.data.message.length);
						if (res.data.message.length == 0) {
							return;
						} else {
							this.isshow = true;
							for (var i = 0; i <= res.data.message.length - 1; i++) {
								this.list.push(res.data.message[i]);
							}
						}
					})
					.catch(err => {
						console.log('请求失败' + err);
					});
			}
		},
		change(e) {
			// 删除的索引
			console.log(this.list[e].id);
			var id = this.list[e].id;
			uni.showModal({
				// e选择索引
				content: '删除此条收藏?' + id,
				success: res => {
					if (res.confirm) {
						this.$axios
							.get('http://127.0.0.1:3000/delcoll', {
								// 携带的参数，在url中解析
								params: {
									id: id
								}
							})
							.then(res => {
								console.log('删除成功');
								this.list = [];
								this.add(1);
							})
							.catch(err => {
								console.log('删除失败' + err);
							});
					} else {
						console.log('取消删除');
					}
				}
			});
		}
	}
};
</script>

<style>
.collection {
	width: 100%;
	margin: 0 20rpx;
}
.not-coll {
	text-align: center;
	margin-top: 300rpx;
	font-size: 36rpx;
}
.list {
	position: relative;
	width: 100%;
	height: 200rpx;
	border-radius: 20rpx;
	margin-top: 28rpx;
}
.title {
	position: relative;
	left: 30rpx;
	top: 30rpx;
	font-size: 48rpx;
}
.price {
	position: absolute;
	left: 274px;
	top: 80px;
	color: #222222;
	font-size: 20rpx;
}
.brief {
	position: absolute;
	left: 30rpx;
	top: 110rpx;
	font-size: 26rpx;
	color: #333333;
	width: 400rpx;
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}
.time {
	position: absolute;
	left: 500rpx;
	top: 150rpx;
	font-size: 26rpx;
	color: #333333;
}
.showText {
	margin-top: 200rpx;
	text-align: center;
}
</style>
