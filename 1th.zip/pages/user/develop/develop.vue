<template>
	<view class="develop"><time-line ref="timeline" location="center" title="发展里程"></time-line></view>
</template>

<script>
import timeLine from '../../../components/xuan-timeLine/xuan-timeLine.vue';
export default {
	data() {
		return {
			time: 0,
			isclick: true
		};
	},
	components: {
		timeLine
	},
	methods: {
		timer() {
			if (this.time > 0) {
				this.isclick = false;
				this.time--;
				setTimeout(this.timer, 1);
			} else {
				this.isclick = true;
				this.time = 10;
			}
		}
	}
};
</script>

<style></style>
