<template>
	<view class="setself">
		<!-- 头像 -->
		<form @submit="formSubmit">
			<view class="header " @click="chooseHeader">
				头像
				<view class="headerimg"><image :src="imgArr" mode="aspectFill"></image></view>
				<icon class="iconfont iconarrow-right-copy-copy listRight"></icon>
			</view>
			<!-- 昵称 -->
			<view class="name set">
				昵称
				<input class="setview" type="text" :value="name" confirm-type="done" @blur="inputname" placeholder="请输入昵称" />
			</view>
			<!-- 电话 -->
			<view class="phone set">
				电话
				<input class="setview" disabled="true" @blur="inputphone" type="text" :value="phone" confirm-type="done" placeholder="请输入电话号码" />
			</view>
			<!-- 性别	 -->
			<view class="sex set">
				性别
				<view class="uni-list-cell-db setsex">
					<picker @change="bindPickerChange" :value="index" :range="array">
						<view class="uni-input">{{ array[index] }}</view>
					</picker>
				</view>
			</view>
			<!-- 描述 -->
			<view class="description set">
				描述
				<input class="setview desInput" @blur="inputdescrit" type="text" :value="description" confirm-type="done" placeholder="请输入描述" />
			</view>

			<button class="tablogin" form-type="submit" type="warn">保存</button>
		</form>
		<!-- <button class="tablogin" size="default" type="warn" form-type="submit">保存</button> -->
	</view>
</template>

<script>
export default {
	data() {
		return {
			// views保存修改的数据
			// views: [],
			name:"",
			imgArr: '',
			phone: '',
			description: '',
			array: ['男', '女'],
			index:0,
			// views:''
		};
	},
	onShow: function() {
		this.imgArr = uni.getStorageSync('userheaderimg');
		this.phone = uni.getStorageSync('username')
		console.log(this.phone)
		this.showview(1);
	},

	methods: {
		// 上传头像
		chooseHeader:function() {
			uni.chooseImage({
				count: 1,
				success: res => {
					console.log(res.tempFilePaths);
					this.imgArr = res.tempFilePaths;
				}
			});
		},
		// 性别
		bindPickerChange: function(e) {
			this.index = e.target.value;
		},
		// 名字
		inputname: function(e) {
			this.name = e.detail.value;
			console.log(this.name);
		},
		// 电话  暂时不需要功能
		inputphone: function(e) {
			if (!/^1[3456789]\d{9}$/.test(e.detail.value)) {
				uni.showModal({
					content: '请输入正确的手机号：',
					showCancel: false
				});
				return false;
			} else {
				this.phone = e.detail.value;
			}
		},
		// ，描述
		inputdescrit: function(e) {
			this.description = e.detail.value;
		},
		// 提交
		formSubmit: function(e) {
			this.$axios
				.get('http://127.0.0.1:3000/postsetuser', {
					params: {
						name: this.name,
						phone:this.phone,
						sex: this.index,
						describe: this.description
					}
				})
				.then(res => {
					console.log('请求成功');
					uni.showModal({
						// content: '保存成功：' + JSON.stringify(formdata),
						content: '保存成功',
						showCancel: false
					});
				})
				.catch(err => {
					console.log('请求失败' + err);
				});
			// //保存头像地址
			uni.setStorageSync('userheaderimg', this.imgArr);
				// 提交图片，保存在本地形式
			uni.setStorage({
						key:'userheaderimg',
						data:this.imgArr,
						success:function(){
							console.log("上图片传成功")
						}
					})
			
		},
		//获取用户信息 
		showview:function(e){
			this.$axios.get('http://127.0.0.1:3000/getusers',{
				params:{
					phone:this.phone
				}
			})
			.then(res=>{
			 console.log('用户信息获取成功')
			 const data = res.data.message[0];
			 if(data.username!==null){
				 this.name = data.username
			 }else {
				 this.name = ''
			 }
			 	// this.description = data.des
			 if(data.description!==null){
			 		this.description = data.des
			 }else {
			 		this.description = ''
			 }
			 // 用户标志 0 为男 1为女
			 this.index = data.sex
			})
			.catch(err=>{
			console.log(err)
			})
		}
	}
};
</script>

<style>
.setself {
	width: 100%;
	height: 100%;
	padding: 0 20rpx;
}
.header {
	height: 180rpx;
	border-bottom: 1rpx solid #cccccc;
	line-height: 180rpx;
}
.header .listRight {
	position: absolute;
	right: 20rpx;
	color: #cccccc;
}
.headerimg {
	/* width: ; */
	position: absolute;
	top: 10rpx;
	right: 80rpx;
	height: 160rpx;
	width: 200rpx;
	overflow: hidden;
}
.name,
.phone,
.sex,
.description {
	position: relative;
}
.setview {
	position: absolute;
	left: 150rpx;
	top: 35rpx;
}
.desInput{
	width: 560rpx;
}
.setsex {
	position: absolute;
	left: 150rpx;
	top: 0rpx;
}

.set {
	width: 100%;
	height: 120rpx;
	border-bottom: 1rpx solid #cccccc;
	line-height: 120rpx;
}
.set text {
	display: inline-block;
}
.set .listRight {
	position: absolute;
	right: 20rpx;
	color: #cccccc;
}
.tablogin {
	position: relative;
	top: 600rpx;
}
</style>
