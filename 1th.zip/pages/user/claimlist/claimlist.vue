<template>
	<view class="claim ">
		<view class="bg-white flex-sub radius " v-if="showloading === 1 ? true : false" >
			<image src="https://image.weilanwl.com/gif/loading-white.gif" mode="aspectFit" class="gif-white response" style="height:200rpx ; margin-top: 200rpx;"></image>
		</view>
		<view class="claim-content" v-if="showloading === 0 ? true : false">
			<!-- 步骤条 -->
			<view class="bg-white padding">
				<view class="cu-steps">
					<view class="cu-item" :class="index > num ? '' : 'text-blue'" v-for="(item, index) in numList" :key="index">
						<text class="num" :class="index == 2 ? 'err' : ''" :data-index="index + 1"></text>
						<!-- {{item.name}} -->
					</view>
				</view>
			</view>
			<!-- 选项卡 -->
			<!-- 第一步-->
			<!-- 类型 -->
			<view class="claim-1">
				<view class="cu-form-group margin-top  claim-from">
					<view class="title">申请类型:</view>
					<picker @change="TypeChange" :value="typeindex" :range="type">
						<view class="picker">{{ typeindex > -1 ? type[typeindex] : '请选择您要申请的理赔类型' }}</view>
					</picker>
				</view>
				<!-- 就诊人 -->
				<view class="cu-form-group margin-top  claim-from">
					<view class="title">就诊人:</view>
					<picker @change="UserChange" :value="userindex" :range="user">
						<view class="picker">{{ userindex > -1 ? user[userindex] : '请选择申请人' }}</view>
					</picker>
				</view>
				<!-- 日期 -->
				<view class="cu-form-group margin-top  claim-from">
					<view class="title">日期选择</view>
					<picker mode="date" :value="date" start="2010-12-31" end="data" @change="DateChange">
						<view class="picker">{{ date }}</view>
					</picker>
				</view>
			</view>
			<!-- 第二步 -->
			<view class="claim-2" v-if="num === 1">
				<view class="cu-bar bg-white ">
					<view class="action">
						身份证正反面/急诊(住院)病历
						<text class="text-gray claim-2-unfoll">身份证正方面</text>
					</view>

					<view class="action">{{ imgList.length }}/9</view>
				</view>
				<view class="cu-form-group">
					<view class="grid col-4 grid-square flex-sub">
						<view class="bg-img" v-for="(item, index) in imgList" :key="index" @tap="ViewImage" :data-url="imgList[index]">
							<image :src="imgList[index]" mode="aspectFill"></image>
							<view class="cu-tag bg-red" @tap.stop="DelImg" :data-index="index"><text class="cuIcon-close"></text></view>
						</view>
						<view class="solids" @tap="ChooseImage" v-if="imgList.length < 9"><text class="cuIcon-cameraadd"></text></view>
					</view>
				</view>
			</view>
			<view class="action claimlist-margintop">
				<button class="cu-btn round line-blue nextstep" @tap="NumSteps" :loading="isloading">{{ nextstep[num] }}</button>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			phone:'',
			typeindex: -1,
			userindex: -1,
			type: [],
			user: [],
			id:[],
			date: new Date().toISOString().slice(0, 10),
			imgList: [],
			num: 0,
			showloading: 0,
			isloading: false,
			numList: [
				{
					name: '下一步'
				},
				{
					name: '完成'
				}
			],
			nextstep: ['下一步', '完成']
		};
	},
	
	onShow: function() {
		this.InsureUser()
	},
	methods: {
		// 传地理赔数据
		SetClaimView(){
			this.$emit('name',)
		},
		// 类型
		TypeChange(e) {
			this.typeindex = e.detail.value;
			console.log(this.id[this.typeindex])
			// 二次查询、查询申请人信息
			this.$axios.get('http://127.0.0.1:3000/getclaimuser',{
							params:{
								id:this.id[this.typeindex]
							}
						})
					.then(res=>{
						var user = new Array
						user = res.data.message
						for(var i = 0 ; i<user.length;i++){
							this.user.push(user[i].insure_username)
						}
					})
					.catch(err=>{
						console.log(err)
					})
		},
		// 就诊人
		UserChange(e) {
		 this.userindex = e.detail.value;
		},
		// 请求申请信息 	
		InsureUser(){
			this.phone = uni.getStorageSync('username')
			this.$axios.get('http://127.0.0.1:3000/getclaim',{
							params:{
								phone:this.phone
							}
						})
					.then(res=>{
						console.log("请求个人保单信息成功")
						var data = new Array
						data = res.data.message
						for(var i = 0 ; i<data.length;i++){
							this.id.push(data[i].insure_id)
							this.type.push(data[i].insure_type)
						}
					})
					.catch(err=>{
						console.log(err)
					})
		},
		//日期 
		DateChange(e) {
			this.date = e.detail.value;
		},
		// 下一步
		NumSteps() {
			var num = (this.num = this.num == this.numList.length - 1 ? 0 : this.num + 1);
			if (num === 0) {
				// 完成理赔
			 	this.$emit('claimName',this.user[this.userindex])
				this.isloading = true;
				this.nextstep[num] = '加载中...';
				this.showloading = 1;
				// 修改理赔转态
				this.$axios.get('http://127.0.0.1:3000/setinsure',{
								params:{
									id:this.id[this.typeindex],
									taken:'1',
								}
							})
						.then(res=>{
							console.log("请求成功")
						})
						.catch(err=>{
							console.log(err)
						})
						
				setTimeout(() => {
					uni.showModal({
						content: '理赔申请完成',
						showCancel: false,
						success: res => {
							if(res.confirm){
								uni.redirectTo({
									url:'../claim'
								})
							}
						}
					});
				}, 1000);
			}
		},
		// 上传照片
		ChooseImage() {
			uni.chooseImage({
				count: 9, //默认9
				sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
				sourceType: ['album'], //从相册选择
				success: res => {
					if (this.imgList.length != 0) {
						this.imgList = this.imgList.concat(res.tempFilePaths);
					} else {
						this.imgList = res.tempFilePaths;
					}
				}
			});
		},
		ViewImage(e) {
			uni.previewImage({
				urls: this.imgList,
				current: e.currentTarget.dataset.url
			});
		},
		//删除照片
		DelImg(e) {
			uni.showModal({
				// title: '召唤师',
				content: '确定要删除这张照片吗？',
				cancelText: '取消',
				confirmText: '确定',
				success: res => {
					if (res.confirm) {
						this.imgList.splice(e.currentTarget.dataset.index, 1);
					}
				}
			});
		}
		
	}
};
</script>

<style>
.claim {
	width: 100%;
}
.claim-from {
	height: 100rpx;
	padding: 0 20rpx;
	margin-top: 10rpx;
}
.nextstep {
	width: 100%;
	height: 85rpx;
}
.claim-2-unfoll {
	font-size: 20rpx;
	margin-left: 20rpx;
}
.claimlist-margintop{
	margin-top: 80rpx;
}
</style>
