<template>
	<view class="insure">
		<view class="bg-gradual-blue shadow-warp list" v-for="(item, index) in list" :key="index" v-show="hViews">
			<text class="title">{{ item.insure_type}}</text>
			<text class="name">保险人:{{ item.insure_username }}</text>
			<text class="time">{{ item.insure_time }}</text>
		</view>
		<view class="isnothing" v-show="!hViews">
			<text>客官,这什么都没有。。。
			<view ></view>
			快去投保吧!
			</text>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			list: [],
			phone:'',
			hViews:false
		};
	},
	onShow: function() {
		this.phone = uni.getStorageSync('username')
		this.getCollection(1);
	},
	methods: {
		getCollection(e) {
			if (e == 1) {
				this.$axios
					.get('http://127.0.0.1:3000/getinsure',{
						params:{
							phone:this.phone
						}
					})
					.then(res => {
						console.log('请求成功');
						console.log(res.data.message.length);
						if(res.data.message.length == 0){
							console.log("没有")
							
						}else{
							this.hViews = true;
							for (var i = 0; i <= res.data.message.length-1 ; i++) {
								this.list.push(res.data.message[i]);
								// var insureTime = new Array();
								// var T = insureTime.push(res.data.message[i].insure_time);
								// console.log(insureTime.toString())
							}
							console.log(this.list)
						}
						
						
					})
					.catch(err => {
						console.log('请求失败' + err);
					});
			}
		}
	}
};
</script>

<style>
.insure {
	width: 100%;
	margin: 0 20rpx;
}
.list {
	position: relative;
	width: 100%;
	height: 200rpx;
	border-radius: 20rpx;
	margin-top: 28rpx;
	/* box-shadow: 0rpx 6rpx 8rpx 8rpx #CCCCCC; */
}
.title {
	position: relative;
	left: 30rpx;
	top: 30rpx;
	font-size: 48rpx;
}
.name {
	position: absolute;
	left: 480rpx;
	top: 46rpx;
	color: #222222;
	font-size: 30rpx;
}
.time {
	position: absolute;
	left: 500rpx;
	top: 150rpx;
	font-size: 26rpx;
	color: #333333;
}
.isnothing{
	margin-top: 300rpx;
	text-align: center;
	font-size: 40rpx;
	line-height: 80rpx;
}
</style>
