<template>
	<view class="content">
		<!-- 个人信息 -->
		<view class="self shadow-warp">
			<view class="y_login" v-show="islogin == 1">
				<view class="header">
					<view class="userImg" @click="lookHeader(imgArr)">
						<image :src="imgArr" mode="aspectFit" style="width: 140rpx; height: 140rpx; border-radius: 50%;"></image>
						<text class="lookHeader" @click="lookHeader(imgArr)">查看头像</text>
					</view>
					<text class="userName">{{ name }}</text>
					<text class="userPhone">{{ phone }}</text>
					<text class="userDescription">签名:{{ description }}</text>
				</view>
				<!-- 修改个人信息   标识4-->
				<text class="iconfont iconset set" @click="checkedTro(4)"></text>
			</view>
			<view class="n_login" @click="bindLogin" v-show="islogin == 0">
				<view class="tologin">
					<text>
						您还没有登录，去登录吧
						<text class="cuIcon-right"></text>
					</text>
				</view>
			</view>
		</view>
		<!-- 操作 -->
		<view class="userTro">
			<view class="userItem" @click="checkedTro(1)">
				<image src="../../static/img/user1.png" mode=""></image>
				<text>我的保单</text>
			</view>
			<view class="userItem" @click="checkedTro(2)">
				<image src="../../static/img/user3.png" mode=""></image>
				<text>我的收藏</text>
			</view>
			<view class="userItem" @click="checkedTro(3)">
				<image src="../../static/img/user2.png" mode=""></image>
				<text>理赔服务</text>
			</view>
		</view>
		<view class="userList">
			<view class="list" @click="checkedTro(5)">
				<text class="iconzuji  iconfont"></text>
				<text>蚁蚁发展</text>
				<text class="iconfont iconarrow-right-copy-copy listRight"></text>
			</view>
			<view class="list" @click="checkedTro(6)">
				<text class="iconfont iconpinpaibiaoshi-mayi"></text>
				<text>关于蚁蚁</text>
				<text class="iconfont iconarrow-right-copy-copy listRight"></text>
			</view>
			<view class="list" @click="checkedTro(7)">
				<text class="iconfont iconV"></text>
				<text>客服</text>
				<text class="iconfont iconarrow-right-copy-copy listRight"></text>
			</view>
			<view class="list" @click="checkedTro(8)">
				<text class="iconfont iconfenxiang"></text>
				<text>分享</text>
				<text class="iconfont iconarrow-right-copy-copy listRight"></text>
			</view>
			<!-- <view class="list" @click="getUser">
				<text class="iconfont iconfenxiang"></text>
				<text>获取用户信息</text>
				<text class="iconfont iconarrow-right-copy-copy listRight"></text>
			</view> -->
		</view>
		<view class="btn-row">
			<button v-if="islogin == 0" type="primary" class="primary " @tap="bindLogin">登录</button>
			<button v-if="islogin == 1" type="default" @tap="bindLogout">退出登录</button>
		</view>
	</view>
</template>

<script>
import { mapState, mapMutations } from 'vuex';

export default {
	data() {
		return {
			imgArr: '',
			name: '',
			phone: '',
			description: '',
			itemList: [],
			islogin: '', //0已登录   1未登录
			// 保存登录的账号
			loginNum: ''
		};
	},
	computed: {
		...mapState(['hasLogin', 'forcedLogin'])
	},
	onLoad: function(op) {},
	onShow: function() {
		const logintaken = uni.getStorageSync('islogin');
		this.islogin = logintaken;
		// 获取登录的用户名，拿到数据库信息
		const getname = uni.getStorageSync('username');
		this.loginNum = getname;
		// 获取用户信息
		this.showview(1);
	},
	methods: {
		// 查看头像
		lookHeader(current) {
			uni.previewImage({
				urls: this.imgArr,
				// 操作图片
				longPressActions: {
					// itemList: ['查看图片'],
					// success: function(data) {
					//     console.log('选中了第' + (data.tapIndex + 1) + '个按钮,第' + (data.index + 1) + '张图片');
					// },
					// fail: function(err) {
					//     console.log(err.errMsg);
					// }
				}
			});
		},
		...mapMutations(['logout']),
		// 从user去登录
		bindLogin() {
			uni.navigateTo({
				url: '../login/login'
			});
		},
		// 退出登录
		bindLogout() {
			// this.logout();
			/**
			 * 如果需要强制登录跳转回登录页面
			 */
			// 改变登录转态islogin
			uni.setStorage({
				key: 'islogin',
				data: '0'
			});
			// 删除本地用户名
			uni.removeStorageSync('username');
			uni.reLaunch({
				url: '../login/login'
			});
		},
		// 信息操作
		checkedTro(e) {
			// if(this.loginNum){
			// 	console.log('已登录')
			// }else{
			// 	console.log('未登录')
			// }

			if (e === 1) {
				//我的保单
				if (this.loginNum) {
					uni.navigateTo({
						url: './insure'
					});
				} else {
					this.bindLogin();
				}
			} else if (e === 2) {
				//我的收藏
				if (this.loginNum) {
					uni.navigateTo({
						url: './collection'
					});
				} else {
					this.bindLogin();
				}
			} else if (e === 3) {
				//理赔服务
				if (this.loginNum) {
					uni.navigateTo({
						url: './claim'
					});
				} else {
					this.bindLogin();
				}
			} else if (e === 4) {
				//个人信息设置
				if (this.loginNum) {
					uni.navigateTo({
						url: './setself'
					});
				} else {
					this.bindLogin();
				}
			} else if (e === 5) {
				//蚁蚁发展
				uni.navigateTo({
					url: './develop/develop'
				});
			} else if (e === 6) {
				// 关于蚁蚁
				uni.navigateTo({
					url: './about/about'
				});
			} else if (e === 7) {
				//客服
				uni.navigateTo({
					url: ''
				});
				uni.showModal({
					title: '模块未开放',
					showCancel: false
				});
			} else if (e === 8) {
				// 分享
				uni.share({
					provider: 'weixin',
					scene: 'WXSceneSession',
					type: 2,
					imageUrl: '../../static/img/userweixin.jpg',
					success: function(res) {
						console.log('success:' + JSON.stringify(res));
					},
					fail: function(err) {
						console.log('fail:' + JSON.stringify(err));
					}
				});
			}
		},
		// http://jsonplaceholder.typicode.com/posts
		// 获取用户信息
		showview: function(e) {
			this.$axios
				.get('http://127.0.0.1:3000/getusers', {
					params: {
						phone: this.loginNum
					}
				})
				.then(res => {
					// console.log(' 请求成功')
					const views = res.data.message[0];
					this.phone = views.phone;
					this.name = views.username;
					this.description = views.des;
					this.index = views.sex;
				})
				.catch(err => {
					console.log(err);
				});
		}
	}
};
</script>

<style scoped>
.content {
	padding: 20rpx 20rpx;
	width: 100%;
	margin: 0 auto;
}
.self {
	width: 100%;
	height: 300rpx;
	background-color: #f1f1f1;
	border-radius: 30rpx;
	/* box-shadow: 0rpx 8rpx 14rpx 5rpx #CCCCCC ; */
}
.n_login {
	text-align: center;
	line-height: 300rpx;
	font-size: 40rpx;
}

/* 头像 */
.header {
	position: relative;
	margin-left: 20rpx;
	margin-top: 60rpx;
}
.userImg {
	display: inline-block;
	width: 140rpx;
	height: 140rpx;
	border-radius: 50%;
	background-color: #0086b3;
}
.userName {
	position: relative;
	display: inline-block;
	top: -90rpx;
	left: 60rpx;
	font-size: 40rpx;
}
.userPhone {
	position: relative;
	top: -90rpx;
	left: 100rpx;
	font-size: 30rpx;
}
.userDescription {
	display: block;
	display: -webkit-box;
	width: 480rpx;
	position: absolute;
	top: 90rpx;
	left: 200rpx;
	font-size: 30rpx;
	color: #999999;
	/* 两行显示... */
	overflow: hidden;
	text-overflow: ellipsis;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
}

.lookHeader {
	position: absolute;
	display: block;
	height: 30rpx;
	/* width: 60rpx; */
	background-color: #0faeff;
	border-radius: 10rpx;
	font-size: 14rpx;
	color: #ffffff;
	text-align: center;
	line-height: 30rpx;
	left: 40rpx;
	top: 130rpx;
}
.set {
	position: absolute;
	right: 50rpx;
	top: 10rpx;
	font-size: 60rpx;
}
/* 信息操作 */
.userTro {
	width: 100%;
	height: 160rpx;
	margin-top: 20rpx;
	display: flex;
	justify-content: space-around;
	font-size: 36rpx;
	border-bottom: 1rpx solid #cccccc;
}
.userItem {
}
.userItem image {
	display: block;
	width: 81rpx;
	height: 81rpx;
	margin: 0 auto;
}
.list {
	width: 100%;
	height: 100rpx;
	font-size: 36rpx;
	line-height: 100rpx;
	border-bottom: 1rpx solid #cccccc;
}
.list text:nth-child(2) {
	margin-left: 10rpx;
}
.list text:nth-child(1) {
	margin-left: 10rpx;
}
.listRight {
	position: absolute;
	right: 0rpx;
	margin-right: 10rpx;
}
</style>
