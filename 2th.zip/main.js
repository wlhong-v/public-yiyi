// vue初始入口文件
import Vue from 'vue'
import App from './App'
// 引入axios
import axios from 'axios'
// Vue.use(vant);
// 挂载index主文件到config
// import config from './store/index.js'
import store from './store'

// productionTip  阻止生产环境消息
// Vue.config.productionTip = false
Vue.prototype.$store = store
Vue.prototype.$axios = axios
// Vue.use(axios);
//挂载config到原型  可通过this.config访问
// Vue.prototype.$config = config
// 定义实例，备用
App.mpType = 'app'
// 实例化对象
const app = new Vue({
    store,
    ...App,
	axios
})
app.$mount()
