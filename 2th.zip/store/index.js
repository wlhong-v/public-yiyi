
import Vue from 'vue'
import Vuex from 'vuex'
// 引入一下js文件
// import user from '../api/user/users.js'

Vue.use(Vuex)

const store = new Vuex.Store({
	modules:{
			   // user:user,
	},
	// 存放数据
    state: {
        /**
         * 是否需要强制登录
         */
        forcedLogin: false,
        hasLogin: false,
        userName: ""
    },
	// 处理数据逻辑方法（全部放在这里  使视图与逻辑分离）
    mutations: {
        login(state, userName) {
            state.userName = userName || '新用户';
            state.hasLogin = true;
        },
        logout(state) {
            state.userName = "";
            state.hasLogin = false;
        }
    }
})

export default store
